from fastapi import APIRouter
from pydantic import BaseModel
from database import db

router = APIRouter(prefix="/api/members", tags=["Members"])

class Member(BaseModel):
    name: str
    phone: str
    points: int = 0

@router.get("/{phone}")
async def get_member(phone: str):
    m = await db.members.find_one({"phone": phone})
    return m or {}

@router.post("/")
async def create_member(member: Member):
    await db.members.insert_one(member.dict())
    return {"message": "Member created"}

@router.put("/{phone}/points")
async def update_points(phone: str, data: dict):
    await db.members.update_one({"phone": phone}, {"$set": {"points": data["points"]}})
    return {"message": "Points updated"}